#ifndef __ENCODER2_H
#define __ENCODER2_H

void Encoder2_Init(void);

int16_t Encoder2_Get(void);




#endif









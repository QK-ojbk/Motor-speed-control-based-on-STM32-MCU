#ifndef _DHT11_H
#define _DHT11_H

uint8_t DHT11Init(void);
uint8_t DHT11ReadData(uint8_t *Humi,uint8_t *Temp);

#endif


